<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/','StudentController@index');
Route::get('data/create','StudentController@create');
Route::post('/','StudentController@store');
Route::get('data/edit/{id}','StudentController@edit');
Route::post('data/update/{id}','StudentController@update');
Route::delete('data/{id}','StudentController@destroy');
Route::get('data/{id}','StudentController@show');