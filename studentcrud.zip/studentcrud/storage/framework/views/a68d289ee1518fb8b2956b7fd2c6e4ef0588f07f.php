<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form role="form" action="/" method="post" enctype="multipart/from-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>

        <label for="nama">Nama</label><br>
        <input type="text" id="nama" name="nama"><br>
        <label for="jurusan">Jurusan</label><br>
        <input type="text" id="jurusan" name="jurusan"><br>
        <input type="submit" id="submit">
    </form>
</body>
</html><?php /**PATH C:\Users\Kenneth\Downloads\aplikasi\studentcrud\resources\views/create.blade.php ENDPATH**/ ?>