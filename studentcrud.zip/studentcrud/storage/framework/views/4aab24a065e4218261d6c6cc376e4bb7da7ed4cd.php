<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan CRUD</title>
</head>
<body>
<a href="data/create"><input type="submit" value="databaru" style="margin-left: 550px;"></a><br><br>
<table border="1" width="100%">     
        <tr style="text-align: center;">
            <th>Nama</th>
            <th>Jurusan</th>
            <th>Action</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $postdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        
        <tr style="text-align: center;">
            <td><?php echo e($post -> nama); ?></td>
            <td><?php echo e($post -> jurusan); ?></td>
            <td>
            <a href="data/edit/<?php echo e($post->id); ?>"><input type="submit" value="ubahdata"></a>
            <a href="data/<?php echo e($post->id); ?>"><input type="submit" value="Show"></a>
            <!-- <a href="data/<?php echo e($post->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" value="Delete">
            </a> -->
            <form action="data/<?php echo e($post->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <input type="submit" value="Delete">
            </form>               
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td align = "center">No Data</td></tr>
        <?php endif; ?>    
</table>
</body>
</html><?php /**PATH C:\Users\Kenneth\Downloads\aplikasi\studentcrud\resources\views/home.blade.php ENDPATH**/ ?>