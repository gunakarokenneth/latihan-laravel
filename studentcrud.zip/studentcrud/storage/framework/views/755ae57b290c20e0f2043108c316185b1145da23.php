<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
</head>
<body>
    <h1>Tampilkan data</h1>

    <h2>Nama saya <?php echo e($postdata->nama); ?> jurusan <?php echo e($postdata->jurusan); ?></h2>

    <a href="/"><input type="submit" value="Back"></a>
</body>
</html><?php /**PATH C:\Users\Kenneth\Downloads\aplikasi\studentcrud\resources\views/detail.blade.php ENDPATH**/ ?>