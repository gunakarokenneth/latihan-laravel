<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan CRUD</title>
</head>
<body>
<a href="data/create"><input type="submit" value="databaru" style="margin-left: 550px;"></a><br><br>
<table border="1" width="100%">     
        <tr style="text-align: center;">
            <th>Nama</th>
            <th>Jurusan</th>
            <th>Action</th>
        </tr>
        @forelse($postdata as $key => $post)
        
        <tr style="text-align: center;">
            <td>{{$post -> nama}}</td>
            <td>{{$post -> jurusan}}</td>
            <td>
            <a href="data/edit/{{$post->id}}"><input type="submit" value="ubahdata"></a>
            <a href="data/{{$post->id}}"><input type="submit" value="Show"></a>
            <!-- <a href="data/{{$post->id}}" method="post">
                @csrf
                @method('DELETE')
                <input type="submit" value="Delete">
            </a> -->
            <form action="data/{{$post->id}}" method="post">
                @csrf
                @method('DELETE')
                <input type="submit" value="Delete">
            </form>               
            </td>
        </tr>
        @empty
        <tr><td align = "center">No Data</td></tr>
        @endforelse    
</table>
</body>
</html>