<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
</head>
<body>
    <h1>Tampilkan data</h1>

    <h2>Nama saya {{$postdata->nama}} jurusan {{$postdata->jurusan}}</h2>

    <a href="/"><input type="submit" value="Back"></a>
</body>
</html>